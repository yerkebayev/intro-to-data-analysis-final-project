from bs4 import BeautifulSoup as bs
from selenium import webdriver
import csv

BASE_URL = 'https://www.flip.kz'
books_for_table = []
columns = ['Name', 'Author', 'Rate Average', 
           'Count of Reviews', 'Price', 'Category', 
           'Publishing House', 'Binding', 'In stock', 
           'ISBN', 'Number of pages', 'Paper type', 'Release date']

def getDataFromUrl(URL):
    driver.get(BASE_URL + str(URL))
    content = driver.page_source
    soup = bs(content, 'html.parser')
    table_of_item = soup.find(id='prod')
    if table_of_item is None:
        return
    book_name = None
    book_name_tag = table_of_item.find(itemprop='name')
    if book_name_tag is not None:
        book_name = book_name_tag.text

    book_author = None
    book_author_tag = table_of_item.find(style='margin-bottom: 0px;')
    if book_author_tag is not None:
        book_author_tag_tag = book_author_tag.find('a')
        if book_author_tag_tag is not None:
            book_author = book_author_tag_tag.text
    
    book_average_rating = None
    book_review_count = 0
    book_rating_tag = table_of_item.find(class_='rating-layer')
    book_average_rating_tag = book_rating_tag.find(itemprop='ratingValue')
    if book_average_rating_tag is not None:
        book_average_rating = book_average_rating_tag.text
    book_review_count_tag = book_rating_tag.find(itemprop='reviewCount')
    if book_review_count_tag is not None:
        book_review_count = book_review_count_tag.text


    book_price = 'N/A'
    book_price_tag = table_of_item.find(itemprop='price')
    if book_price_tag is not None:
        book_price = book_price_tag.get('content')

    book_delivery_type_tag = soup.find(class_='delivery-in-type')
    book_delivery_type = book_delivery_type_tag.text

    book_category_tag = soup.find(class_='krohi')

    book_category_all = book_category_tag.find_all(itemprop='name')
    book_category = book_category_all[len(book_category_all) - 1].text

    book_accordion = soup.find(class_='accordion')
    book_accordion_rows = book_accordion.find_all(class_='row')

    book_publishing_house = None
    book_isbn = None
    book_binding = None
    book_number_of_pages = None
    book_paper_type = None
    book_release_year = None
    
    for book_row in book_accordion_rows:
        book_row_cells = book_row.find_all(class_='cell')
        book_row_name = book_row_cells[0].text
        book_row_data = book_row_cells[1].text
        if book_row_name == 'Издательство':
            book_publishing_house = book_row_data
        elif book_row_name == 'ISBN':
            book_isbn = book_row_data
        elif book_row_name == 'Переплет':
            book_binding = book_row_data
        elif book_row_name == 'Количество страниц':
            book_number_of_pages = book_row_data
        elif book_row_name == 'Бумага':
            book_paper_type = book_row_data
        elif book_row_name == 'Дата выхода':
            book_release_year = book_row_data

    books_for_table.append([book_name,
                            book_author,
                            book_average_rating,
                            book_review_count,
                            book_price,
                            book_category,
                            book_publishing_house,
                            book_binding,
                            book_delivery_type,
                            book_isbn,
                            book_number_of_pages,
                            book_paper_type,
                            book_release_year])
    


driver = webdriver.Chrome()
for i in range(1, 26):
    URL = BASE_URL + '/catalog?subsection=1&filter-show=1&page=' + str(i)
    driver.get(URL)
    content = driver.page_source
    soup = bs(content, 'html.parser')
    book_items = soup.find_all(class_='pic l-h-250')
    for b in book_items:
        link = b.get('href')
        getDataFromUrl(link)


with open('flip_books_new_new.csv', 'w', newline='') as csvfile: 
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(columns)
    csvwriter.writerows(books_for_table)

driver.close()
    